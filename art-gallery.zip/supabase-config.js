
const SUPABASE_URL = "https://poeakbsfalpyjlzntmun.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBvZWFrYnNmYWxweWpsem50bXVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM1NzExOTgsImV4cCI6MjA2OTE0NzE5OH0.Xj8-U5s4fP9oIeX7_FOKOdyafo4ktBj-ht-TK9sdasM";

const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
